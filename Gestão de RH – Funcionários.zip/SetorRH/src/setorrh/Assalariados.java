package setorrh;

public class Assalariados extends Funcionarios {

    double salarioMensal;

    public Assalariados() {
    }

    public Assalariados(String nome, String cpf, String endereco, String telefone, String setor, double salarioMensal) {
        super(nome, cpf, endereco, telefone, setor);
        this.salarioMensal = salarioMensal;
    }

    @Override
    public double calcularSalario() {
        return salarioMensal;
    }

}
