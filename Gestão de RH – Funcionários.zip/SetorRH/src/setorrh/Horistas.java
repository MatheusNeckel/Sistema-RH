package setorrh;

public class Horistas extends Funcionarios {

    private int hora;
    private double valorHora;

    public Horistas() {
    }

    public Horistas(String nome, String cpf, String endereco, String telefone, String setor, int hora, double valorHora) {
        super(nome, cpf, endereco, telefone, setor);
        this.hora = hora;
        this.valorHora = valorHora;
    }

    @Override
    public double calcularSalario() {
        return hora * valorHora;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public double getValorHora() {
        return valorHora;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }

}
