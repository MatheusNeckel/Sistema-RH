package setorrh;

import java.util.Scanner;

public class SetorRH {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Funcionarios[] funcionarios = new Funcionarios[10];
        int count = 0;
        String nome = "";

        do {
            System.out.println("----Cadastrar Funcionários----");
            System.out.print("Digite o nome do funcionário: ");
            nome = entrada.next();

            if (nome.equalsIgnoreCase("PARE")) {
                break;
            }

            System.out.print("Digite o CPF do funcionário: ");
            String cpf = entrada.next();
            System.out.print("Digite o tipo de funcionário: ");
            String tipo = entrada.next();
            System.out.print("Digite o endereço do funcionário: ");
            String endereco = entrada.next();
            System.out.print("Digite o telefone do funcionário: ");
            String telefone = entrada.next();
            System.out.print("Digite o setor do funcionário: ");
            String setor = entrada.next();

            if (count < 10) {
                if (tipo.equalsIgnoreCase("Assalariado")) {
                    System.out.print("Digite o salário: ");
                    double salario = entrada.nextDouble();
                    funcionarios[count] = (new Assalariados(nome, cpf, endereco, telefone, setor, salario));
                    count++;
                    System.out.println("Funcionário cadastrado com sucesso!\n");
                } else if (tipo.equalsIgnoreCase("Horista")) {
                    System.out.print("\nDigite as horas trabalhadas: ");
                    int hora = entrada.nextInt();
                    System.out.print("Digite o valor da hora: ");
                    double valorHora = entrada.nextFloat();
                    funcionarios[count] = (new Horistas(nome, cpf, endereco, telefone, setor, hora, valorHora));
                    count++;
                    System.out.println("Funcionário cadastrado com sucesso!\n");
                } else {
                    System.out.println("Tipo de funcionário não reconhecido. Tente novamente.");
                }
            }
        } while (!nome.equalsIgnoreCase("PARE"));

        System.out.println("\n----Aplicar Aumento Geral----");
        System.out.print("Digite uma porcentagem: ");
        double porcentagem = entrada.nextDouble();

        for (int i = 0; i < count; i++) {
            System.out.println("\n----Dados do Funcionário----");
            System.out.println("Nome: " + funcionarios[i].getNome());
            System.out.println("CPF: " + funcionarios[i].getCpf());
            System.out.println("Endereço: " + funcionarios[i].getEndereco());
            System.out.println("Telefone: " + funcionarios[i].getTelefone());
            System.out.println("Setor: " + funcionarios[i].getSetor());
            System.out.println("Salário do funcionário: " + funcionarios[i].calcularSalario());
            System.out.println("Salário novo do funcionário: " + funcionarios[i].aplicaAumento(porcentagem));
        }
    }
}
